function dfdt  = eq_propagate2(initial_condition, F_eci)
% Lectures_TwoBodyProblem.pdf
% 우주시스템입문 - 도미타 노부유키 eq(7.8) p136
% https://en.wikipedia.org/wiki/Standard_gravitational_parameter
u  = 3.9860064e+14; % earth gravitional parameter
Re = 6378137;      % earth radius [m]

dfdt = zeros(size(initial_condition));

% x=x
% x1=dx/dt
% dx1/dt = d^2(x)/dt

x1 = initial_condition(4); % x1 = dx/dt
y1 = initial_condition(5); % y1 = dy/dt
z1 = initial_condition(6); % z1 = dz/dt
x  = initial_condition(1); % x
y  = initial_condition(2); % y
z  = initial_condition(3); % z

r=sqrt(x^2+y^2+z^2);

% % %   Keplar Motion Equatnion
% % %  => r_dd + u/(r^3)r_ = 0 => r_dd = -u/(r^3)r_
dfdt(1) = x1;
dfdt(2) = y1;
dfdt(3) = z1;
dfdt(4) = -u*x/(r^3) + F_eci(1);
dfdt(5) = -u*y/(r^3) + F_eci(2);
dfdt(6) = -u*z/(r^3) + F_eci(3);

end

