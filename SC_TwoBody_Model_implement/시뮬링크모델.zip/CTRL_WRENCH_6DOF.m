function [F_B_cmd, tau_B_cmd] = CTRL_WRENCH_6DOF( ...
    r_I, v_I, q_IB, omega_B, ...
    r_d, v_d, a_d, q_d, omega_d_B, ...
    m, J)
%#codegen
% ============================================================
% Controller block
% Input :
%   r_I      [3x1] current position in inertial frame
%   v_I      [3x1] current velocity in inertial frame
%   q_IB     [4x1] quaternion [qw qx qy qz], Body -> Inertial
%   omega_B  [3x1] current angular velocity in body frame
%
%   r_d      [3x1] desired position in inertial frame
%   v_d      [3x1] desired velocity in inertial frame
%   a_d      [3x1] desired acceleration in inertial frame
%   q_d      [4x1] desired quaternion, Body -> Inertial
%   omega_d_B[3x1] desired angular velocity in body frame
%
%   m        scalar mass
%   J        [3x3] inertia matrix in body frame
%
% Output:
%   F_B_cmd    [3x1] desired total body force
%   tau_B_cmd  [3x1] desired total body torque
% ============================================================

    % -------------------------
    % Quaternion normalize
    % -------------------------
    q_IB = quat_normalize(q_IB);
    q_d  = quat_normalize(q_d);

    % -------------------------
    % Gains (example)
    % -------------------------
    Kp_r = diag([0.010, 0.010, 0.010]);   % position gain
    Kd_r = diag([0.060, 0.060, 0.060]);   % velocity damping

    Kq   = diag([10.0, 10.0, 10.0]);   % attitude gain
    Kw   = diag([6.0,  6.0,  6.0 ]);   % angular-rate damping

    % -------------------------
    % Position control
    % inertial acceleration command
    % -------------------------
    e_r = r_I - r_d;
    e_v = v_I - v_d;

    a_cmd   = a_d - Kp_r * e_r - Kd_r * e_v;
    F_I_cmd = m * a_cmd;

    % Convert inertial force -> body force
    R_IB    = quat_to_rotm(q_IB);
    F_B_cmd = R_IB.' * F_I_cmd;

    % -------------------------
    % Attitude control
    % q_e = q_d^{-1} ⊗ q_IB
    % -------------------------
    q_e = quat_mul(quat_conj(q_d), q_IB);

    % shortest-path quaternion
    if q_e(1) < 0
        q_e = -q_e;
    end

    e_w = omega_B - omega_d_B;

    % PD + gyro compensation
    tau_B_cmd = -Kq * q_e(2:4) ...
                -Kw * e_w ...
                +cross(omega_B, J * omega_B);
end


% ============================================================
% Local helper functions
% ============================================================

function qn = quat_normalize(q)
    n = norm(q);
    if n < 1e-12
        qn = [1;0;0;0];
    else
        qn = q / n;
    end
end

function qc = quat_conj(q)
    qc = [q(1); -q(2); -q(3); -q(4)];
end

function q = quat_mul(q1, q2)
    % Hamilton product
    w1 = q1(1); x1 = q1(2); y1 = q1(3); z1 = q1(4);
    w2 = q2(1); x2 = q2(2); y2 = q2(3); z2 = q2(4);

    q = [ w1*w2 - x1*x2 - y1*y2 - z1*z2;
          w1*x2 + x1*w2 + y1*z2 - z1*y2;
          w1*y2 - x1*z2 + y1*w2 + z1*x2;
          w1*z2 + x1*y2 - y1*x2 + z1*w2 ];
end

function R = quat_to_rotm(q)
    % q = [qw qx qy qz], Body -> Inertial
    qw = q(1); qx = q(2); qy = q(3); qz = q(4);

    R = [1-2*(qy^2+qz^2),   2*(qx*qy-qz*qw),   2*(qx*qz+qy*qw);
         2*(qx*qy+qz*qw),   1-2*(qx^2+qz^2),   2*(qy*qz-qx*qw);
         2*(qx*qz-qy*qw),   2*(qy*qz+qx*qw),   1-2*(qx^2+qy^2)];
end