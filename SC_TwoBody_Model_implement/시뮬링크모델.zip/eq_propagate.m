function [wd, xd]  = eq_propagate(w, x, Ib, m_tot, ...
                                   Iws, As, Omega, Omegad, ...
                                   RCS_mea, RCS_pos, RCS_vec, R_Ib, ...
                                   T_ext, F_ext)
% % 
% 출력 1: 위성 동체 좌표계 각가속도
% 출력 2: 관성좌표계 선가속도

% % 
RW_h = As*Iws*Omega;
RW_hd = As*Iws*Omegad;

% % 
N = 16;
RCS_f = zeros(3,N);
RCS_t = zeros(3,N);

for i = 1:N
    r_i = RCS_pos(:,i);   % position of thruster i
    d_i = RCS_vec(:,i);   % thrust direction of thruster i

    % force contribution
    RCS_f(:,i) = d_i;

    % torque contribution
    RCS_t(:,i) = cross(r_i, d_i);
end
RCS_f_total = RCS_f * RCS_mea;  % [3x1]
RCS_t_total = RCS_t * RCS_mea;  % [3x1]


%% Rotational Motion
wd = inv(Ib)*(T_ext + RCS_t_total - RW_hd - cross(w, Ib*w + RW_h));

%% Translational Motion

F_I = R_Ib * RCS_f_total;

u  = 3.9860064e+14; % earth gravitional parameter
Re = 6378137;      % earth radius [m]

xd = zeros(size(x));

v1_i = x(4); % x1 = dx/dt
v2_i = x(5); % y1 = dy/dt
v3_i = x(6); % z1 = dz/dt
p1_i = x(1); % x
p2_i = x(2); % y
p3_i = x(3); % z

r=sqrt(p1_i^2+p2_i^2+p3_i^2);

% % %   Keplar Motion Equatnion
% % %  => r_dd + u/(r^3)r_ = 0 => r_dd = -u/(r^3)r_
xd(1) = v1_i;
xd(2) = v2_i;
xd(3) = v3_i;
xd(4) = -u*p1_i/(r^3) + F_I(1) + F_ext(1);
xd(5) = -u*p2_i/(r^3) + F_I(2) + F_ext(2);
xd(6) = -u*p3_i/(r^3) + F_I(3) + F_ext(3);

end

