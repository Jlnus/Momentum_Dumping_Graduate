function qd = fcn(w,q)

F_q = (1/2)*[0 -w(1) -w(2) -w(3);
       w(1) 0 w(3) -w(2);
       w(2) -w(3) 0 w(1);
       w(3) w(2) -w(1) 0];

qd = F_q*q;

end