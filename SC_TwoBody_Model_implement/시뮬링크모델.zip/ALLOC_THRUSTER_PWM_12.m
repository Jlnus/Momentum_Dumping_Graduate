function [u_pwm, F_B_real, tau_B_real] = ALLOC_THRUSTER_PWM_12(F_B_cmd, tau_B_cmd, r, d, F_max)
%#codegen
% ============================================================
% Allocation block
% Input :
%   F_B_cmd    [3x1] desired total body force
%   tau_B_cmd  [3x1] desired total body torque
%
% Output:
%   u_pwm      [12x1] thruster duty command, 0 ~ 1
%   F_B_real   [3x1] realized body force after allocation
%   tau_B_real [3x1] realized body torque after allocation
%
% Example:
%   12-thruster layout for 6DoF control
%   Replace thruster geometry / Tmax below with your real spacecraft values.
% ============================================================

    % Build 6x12 thruster mapping matrix A
    A = build_thruster_matrix( 16, r, d, F_max);

    % Desired wrench
    w_cmd = [F_B_cmd; tau_B_cmd];

    % Bounded least-squares allocation: 0 <= u <= 1
    u_pwm = bounded_allocator_0_1(A, w_cmd);

    % Realized wrench
    w_real     = A * u_pwm;
    F_B_real   = w_real(1:3);
    tau_B_real = w_real(4:6);
end


% ============================================================
% Thruster layout
% ============================================================
function A = build_thruster_matrix(N, r, d, F_max)
    % --------------------------------------------------------
    % Example spacecraft half-size [m]
    % Replace with your real geometry
    % --------------------------------------------------------
    % L = 0.50;   % lever arm

    % --------------------------------------------------------
    % Max thrust of each thruster [N]
    % Replace with your real thruster max force
    % --------------------------------------------------------
    Tmax = F_max * ones(N,1);

    % --------------------------------------------------------
    % Thruster positions r_i in body frame [m]
    % Each column is one thruster position
    % --------------------------------------------------------
    % r = [ ...
    %      0,   0,   0,   0,   L,  -L,   L,  -L,   L,  -L,   L,  -L;
    %      L,  -L,   L,  -L,   0,   0,   0,   0,   L,   L,  -L,  -L;
    %      L,  -L,  -L,   L,   L,  -L,  -L,   L,   0,   0,   0,   0 ];

    % --------------------------------------------------------
    % Thruster unit directions d_i in body frame
    %
    % T1,T2 : +X
    % T3,T4 : -X
    % T5,T6 : +Y
    % T7,T8 : -Y
    % T9,T10: +Z
    % T11,T12:-Z
    % --------------------------------------------------------
    % d = [ ...
    %      1,   1,  -1,  -1,   0,   0,   0,   0,   0,   0,   0,   0;
    %      0,   0,   0,   0,   1,   1,  -1,  -1,   0,   0,   0,   0;
    %      0,   0,   0,   0,   0,   0,   0,   0,   1,   1,  -1,  -1 ];

    % --------------------------------------------------------
    % Build A = [F; tau], size 6x12
    % --------------------------------------------------------
    A = zeros(6,N);

    for i = 1:N
        f_i       = Tmax(i) * d(:,i);
        tau_i     = cross(r(:,i), f_i);
        A(:,i)    = [f_i; tau_i];
    end
end


% ============================================================
% Bounded allocator: 0 <= u <= 1
% Codegen-friendly fixed-size active-set style
% ============================================================
function u = bounded_allocator_0_1(A, w_cmd)
    N = 16;
    u = zeros(N,1);

    % free_mask(i)=true means this thruster is still free to solve
    free_mask = true(N,1);

    lambda = 1e-8;   % small damping

    for iter = 1:(N+1)

        % Residual after fixed/saturated thrusters
        w_res = w_cmd;
        for i = 1:N
            if ~free_mask(i)
                w_res = w_res - A(:,i) * u(i);
            end
        end

        % Collect free columns into Af (fixed-size construction)
        Af  = zeros(6,N);
        idx = zeros(N,1);
        nf  = 0;

        for i = 1:N
            if free_mask(i)
                nf = nf + 1;
                idx(nf) = i;
                Af(:,nf) = A(:,i);
            end
        end

        if nf == 0
            break;
        end

        % Minimum-norm damped solution on free set
        M       = Af * Af.' + lambda * eye(6);
        uf_full = Af.' * (M \ w_res);   % size Nx1, only first nf entries used

        % Put candidate solution into u
        for k = 1:nf
            i = idx(k);
            u(i) = uf_full(k);
        end

        % Check bounds and fix saturated variables
        violated = false;
        for k = 1:nf
            i = idx(k);

            if u(i) < 0
                u(i) = 0;
                free_mask(i) = false;
                violated = true;

            elseif u(i) > 1
                u(i) = 1;
                free_mask(i) = false;
                violated = true;
            end
        end

        if ~violated
            break;
        end
    end

    % Final clipping
    for i = 1:N
        if u(i) < 0
            u(i) = 0;
        elseif u(i) > 1
            u(i) = 1;
        end
    end
end